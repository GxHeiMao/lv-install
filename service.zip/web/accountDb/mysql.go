package accountDb

import (
	"ehang.io/nps/lib/common"
	"errors"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type AccountInfo struct {
	Id            int
	Username      string //用户名
	Password      string //密码
	Mode          string //协议
	ListenIp      string //监听网络
	TotalFlow     int64  //总流量
	UsedFlow      int64  //使用流量
	ExpireTime    string //到期时间
	InletFlow     int64
	ExportFlow    int64
	IsAuth        int    //认证
	Udp           int    //启用UDP
	Status        int    //状态：启用/停用
	Remark        string //备注
	AutoReset     int    //自动复位
	DeviceWarning int    //设备报警
	DeviceLimit   int    //设备限制
	LoginIps      string //登录过的设备IP
	NowConnCount  int32  //在线设备数量
	LockTime      int64  //冻结时间
}

func init() {
	// 需要在init中注册定义的model
	//orm.RegisterModel(new(AccountInfo))
}

func List(search string, status int, startTime, endTime string, length, start int) (int, []AccountInfo) {
	var listInfo []AccountInfo
	o := orm.NewOrm()
	qs := o.QueryTable("account_info")
	if len(search) > 0 {
		qs = qs.Filter("username__icontains", search)
	}
	if status > 0 {
		status--
		qs = qs.Filter("status", status)
	}
	if startTime != "" {
		qs = qs.Filter("expire_time__gte", startTime)
	}
	if endTime != "" {
		qs = qs.Filter("expire_time__lte", endTime)
	}
	count, _ := qs.Count()
	_, err := qs.Limit(length, start).OrderBy("-id").All(&listInfo)
	if err != nil {
		logs.Error("查询数据库失败,err=", err.Error())
	}
	return int(count), listInfo
}
func Save(info AccountInfo) error {
	o := orm.NewOrm()
	var err error
	if len(info.Username) <= 0 {
		return errors.New("请输入用户名")
	}
	oldInfo := OneUserName(info.Username)
	if oldInfo.Id > 0 && info.Id == 0 {
		return errors.New("用户名已存在")
	}
	if oldInfo.Id > 0 && info.Id != oldInfo.Id {
		return errors.New("用户名已存在")
	}
	if info.Id > 0 {
		_, err = o.Update(&info)
	} else {
		_, err = o.Insert(&info)
	}
	return err
}

func SaveChannel(info AccountInfo) error {
	common.DbLock.Lock()
	defer common.DbLock.Unlock()
	o := orm.NewOrm()
	var err error
	_, err = o.Update(&info)
	return err
}

func One(id int) AccountInfo {
	o := orm.NewOrm()
	var info AccountInfo
	info.Id = id
	_ = o.Read(&info)
	return info
}
func Delete(id int) error {
	o := orm.NewOrm()
	var info AccountInfo
	info.Id = id
	_, err := o.Delete(&info)
	return err
}
func OneUserName(name string) AccountInfo {
	o := orm.NewOrm()
	var info AccountInfo
	info.Username = name
	_ = o.Read(&info, "username")
	return info
}

func GetAll() []AccountInfo {
	o := orm.NewOrm()
	var list []AccountInfo
	qs := o.QueryTable("account_info")
	qs.Filter("status", 1).OrderBy("-id").Limit(10000)
	_, _ = qs.All(&list)
	return list
}
