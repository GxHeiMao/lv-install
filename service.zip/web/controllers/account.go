package controllers

import (
	"crypto/md5"
	"ehang.io/nps/lib/common"
	"ehang.io/nps/lib/file"
	"ehang.io/nps/server"
	"ehang.io/nps/web/accountDb"
	"fmt"
	"github.com/astaxie/beego"
	"math/rand"
	"strconv"
	"strings"
	"time"
)

type AccountController struct {
	BaseController
}

func (s *AccountController) List() {
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	start, length := s.GetAjaxParams()
	search := s.getEscapeString("search")
	startTime := s.getEscapeString("startTime")
	endTime := s.getEscapeString("endTime")
	//id := s.GetIntNoErr("id")
	accountStatus := s.GetIntNoErr("accountStatus")
	cnt, list := accountDb.List(search, accountStatus, startTime, endTime, length, start)
	//var cnt int
	//list := make([]file.AccountInfo, 0)
	//if t, err := file.GetDb().GetTask(id); err != nil {
	//	s.error()
	//} else {
	//	if len(t.Account) > 0 {
	//		for _, v := range t.Account {
	//			if len(search) > 0 && !(strings.Contains(v.Username, search) || int(v.TotalFlow) == common.GetIntNoErrByStr(search) || strings.Contains(v.ExpireTime, search) || v.DeviceLimit == common.GetIntNoErrByStr(search)) {
	//				continue
	//			}
	//			if startTime != "" && endTime != "" && !(v.ExpireTime >= startTime && v.ExpireTime <= endTime) {
	//				continue
	//			}
	//			if accountStatus > 0 {
	//				if accountStatus == 1 && v.Status == 0 {
	//					continue
	//				}
	//				if accountStatus == 2 && v.Status == 1 {
	//					continue
	//				}
	//			}
	//			cnt++
	//			if start--; start < 0 {
	//				if length--; length >= 0 {
	//					list = append(list, v)
	//				}
	//			}
	//		}
	//	}
	//}
	s.AjaxTable(list, cnt, cnt, nil)
}

func (s *AccountController) Index() {
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	id := s.GetIntNoErr("id")
	accountStatus := s.GetIntNoErr("accountStatus")
	startTime := s.getEscapeString("startTime")
	endTime := s.getEscapeString("endTime")
	if t, err := file.GetDb().GetTask(id); err != nil {
		s.error()
	} else {
		s.Data["t"] = t
	}

	s.Data["startTime"] = startTime
	s.Data["endTime"] = endTime
	s.Data["Id"] = id
	s.Data["accountStatus"] = accountStatus
	s.display("account/index")
}

func (s *AccountController) Flow() {
	newFlow := s.GetIntNoErr("flow")
	list := accountDb.GetAll()
	//list, _ := server.GetTunnel(0, 1000, "socks5", 0, "")
	if len(list) > 0 {
		for _, tunnel := range list {
			flow := newFlow + int(tunnel.TotalFlow)
			tunnel.TotalFlow = int64(flow)
			err := accountDb.Save(tunnel)
			if err != nil {
				s.AjaxErr(err.Error())
			}
		}
	}
	s.AjaxOk("modified success")
}
func (s *AccountController) Limit() {
	limit := s.GetIntNoErr("limit")
	list, _ := server.GetTunnel(0, 1000, "socks5", 0, "")
	if len(list) > 0 {
		for listK, tunnel := range list {
			list[listK].Client.MaxConn = limit
			list[listK].ServiceMaxConn = limit
			file.GetDb().UpdateTask(list[listK])
			server.StopServer(tunnel.Id)
			server.StartTask(tunnel.Id)
		}
	}
	s.AjaxOk("modified success")
}

func (s *AccountController) Add() {
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	var tplname string
	if s.Data["menu"] == nil {
		s.Data["menu"] = s.actionName
	}
	tplname = strings.Join([]string{"account/add", "html"}, ".")
	ip := s.Ctx.Request.Host
	s.Data["ip"] = common.GetIpByAddr(ip)
	s.Data["bridgeType"] = beego.AppConfig.String("bridge_type")
	if common.IsWindows() {
		s.Data["win"] = ".exe"
	}
	s.Data["p"] = server.Bridge.TunnelPort
	s.Data["proxyPort"] = beego.AppConfig.String("hostPort")
	//生成随机密码
	baseStr := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	baseSymbol := "!@#$%^&*()[]{}+-*/_=."
	s.Data["password"] = s.getRandStr(baseStr+baseSymbol, 12)
	s.TplName = tplname
}
func (s *AccountController) Edit() {
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	accountId := s.GetIntNoErr("accountId")
	info := accountDb.One(accountId)
	if info.Id <= 0 {
		s.error()
	}
	s.Data["accountId"] = accountId
	s.Data["accountInfo"] = info
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	var tplname string
	if s.Data["menu"] == nil {
		s.Data["menu"] = s.actionName
	}
	tplname = strings.Join([]string{"account/edit", "html"}, ".")
	ip := s.Ctx.Request.Host
	s.Data["ip"] = common.GetIpByAddr(ip)
	s.Data["bridgeType"] = beego.AppConfig.String("bridge_type")
	if common.IsWindows() {
		s.Data["win"] = ".exe"
	}
	s.Data["p"] = server.Bridge.TunnelPort
	s.Data["proxyPort"] = beego.AppConfig.String("hostPort")
	s.TplName = tplname
}
func (s *AccountController) getRandStr(baseStr string, length int) string {
	r := rand.New(rand.NewSource(time.Now().UnixNano() + rand.Int63()))
	bytes := make([]byte, length)
	l := len(baseStr)
	for i := 0; i < length; i++ {
		bytes[i] = baseStr[r.Intn(l)]
	}
	return string(bytes)
}

func (s *AccountController) EditAll() {
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	accountIds := s.GetString("accountIds")
	s.Data["accountIds"] = accountIds
	s.Data["web_base_url"] = beego.AppConfig.String("web_base_url")
	var tplname string
	if s.Data["menu"] == nil {
		s.Data["menu"] = s.actionName
	}
	tplname = strings.Join([]string{"account/editAll", "html"}, ".")
	ip := s.Ctx.Request.Host
	s.Data["ip"] = common.GetIpByAddr(ip)
	s.Data["bridgeType"] = beego.AppConfig.String("bridge_type")
	if common.IsWindows() {
		s.Data["win"] = ".exe"
	}
	s.Data["p"] = server.Bridge.TunnelPort
	s.Data["proxyPort"] = beego.AppConfig.String("hostPort")
	s.TplName = tplname
}

func (s *AccountController) Del() {
	id := s.GetIntNoErr("accountId")
	err := accountDb.Delete(id)
	if err != nil {
		s.AjaxErr(err.Error())
	}
	s.AjaxOk("modified success")
}
func (s *AccountController) DelAll() {
	accountIds := s.GetString("accountIds")
	accountArr := strings.Split(accountIds, ",")
	if len(accountArr) <= 0 {
		s.AjaxErr("用户不存在")
	}
	for _, s2 := range accountArr {
		id, _ := strconv.Atoi(s2)
		err := accountDb.Delete(id)
		if err != nil {
			s.AjaxErr(err.Error())
		}
	}
	s.AjaxOk("modified success")
}
func (s *AccountController) EditPassword() {

	accountId := s.GetIntNoErr("accountId")
	pass := s.getEscapeString("pass")
	info := accountDb.One(accountId)
	if len(info.Username) <= 0 {
		s.AjaxErr("用户不存在")
	}
	info.Password = pass
	err := accountDb.Save(info)
	if err != nil {
		s.AjaxErr(err.Error())
	}
	s.AjaxOk("modified success")
}
func (s *AccountController) MD5(str string) string {
	data := []byte(str) //切片
	has := md5.Sum(data)
	md5str := fmt.Sprintf("%x", has) //将[]byte转成16进制
	return md5str
}
func (s *AccountController) Save() {
	//id := s.GetIntNoErr("id")
	accountId := s.GetIntNoErr("accountId")
	var accountInfo accountDb.AccountInfo
	accountInfo.Id = accountId
	accountInfo.ExpireTime = s.getEscapeString("expireTime")
	accountInfo.Password = s.getEscapeString("passwords")
	accountInfo.Mode = "socks"
	accountInfo.ListenIp = s.getEscapeString("serverIp")
	accountInfo.TotalFlow = int64(s.GetIntNoErr("totalFlow"))
	accountInfo.IsAuth = s.GetIntNoErr("isAuth")
	accountInfo.Udp = s.GetIntNoErr("udp")
	accountInfo.Status = s.GetIntNoErr("status")
	accountInfo.Remark = s.getEscapeString("remark")
	accountInfo.AutoReset = s.GetIntNoErr("autoReset")
	accountInfo.DeviceWarning = s.GetIntNoErr("deviceWarning")
	accountInfo.DeviceLimit = s.GetIntNoErr("deviceLimit")
	accountInfo.Username = s.getEscapeString("username")
	err := accountDb.Save(accountInfo)
	if err != nil {
		s.AjaxErr(err.Error())
	} else {
		s.AjaxOk("modified success")
	}
	//if t, err := file.GetDb().GetTask(id); err != nil {
	//	s.AjaxErr("入站规则不存在")
	//} else {
	//
	//	fmt.Println(newAccountInfo)
	//	fmt.Println(accountInfo)
	//	newAccountInfo = append(newAccountInfo, accountInfo)
	//	t.Account = newAccountInfo
	//	file.GetDb().UpdateTask(t)
	//	server.StopServer(t.Id)
	//	server.StartTask(t.Id)
	//	s.AjaxOk("modified success")
	//}
}

func (s *AccountController) SaveAll() {
	accountIds := s.GetString("accountIds")
	accountArr := strings.Split(accountIds, ",")
	if len(accountArr) <= 0 {
		s.AjaxErr("用户信息不存在")
	}
	for _, s2 := range accountArr {
		idInt, _ := strconv.Atoi(s2)
		info := accountDb.One(idInt)
		if len(info.Username) <= 0 {
			s.AjaxErr("用户信息不存在")
		}
		expireTime := s.getEscapeString("expireTime")
		if len(expireTime) > 0 {
			info.ExpireTime = expireTime
		}
		password := s.getEscapeString("passwords")
		if len(password) > 0 {
			info.Password = password
		}
		ip := s.getEscapeString("serverIp")
		if len(expireTime) > 0 {
			info.ListenIp = ip
		}
		totalFlow := s.getEscapeString("totalFlow")
		if len(totalFlow) > 0 {
			flowInt, _ := strconv.Atoi(totalFlow)
			info.TotalFlow = int64(flowInt)
		}
		deviceLimit := s.getEscapeString("deviceLimit")
		if len(deviceLimit) > 0 {
			info.DeviceLimit, _ = strconv.Atoi(deviceLimit)
		}
		remark := s.getEscapeString("remark")
		if len(remark) > 0 {
			info.Remark = remark
		}
		udp := s.GetString("udp")
		if len(udp) > 0 && udp != "2" {
			info.Udp, _ = strconv.Atoi(udp)
		}
		isAuth := s.GetString("isAuth")
		if len(isAuth) > 0 && isAuth != "2" {
			info.IsAuth, _ = strconv.Atoi(isAuth)
		}
		status := s.GetString("status")
		if len(status) > 0 && status != "2" {
			info.Status, _ = strconv.Atoi(status)
		}
		autoReset := s.GetString("autoReset")
		if len(autoReset) > 0 && autoReset != "2" {
			info.AutoReset, _ = strconv.Atoi(autoReset)
		}
		deviceWarning := s.GetString("deviceWarning")
		if len(deviceWarning) > 0 && deviceWarning != "2" {
			info.DeviceWarning, _ = strconv.Atoi(deviceWarning)
		}
		err := accountDb.Save(info)
		if err != nil {
			s.AjaxErr(err.Error())
		}
	}
	s.AjaxOk("modified success")
}
